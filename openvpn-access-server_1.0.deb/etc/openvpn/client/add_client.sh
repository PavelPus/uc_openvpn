openvpn --tls-crypt-v2 /etc/openvpn/server/server.pem --genkey tls-crypt-v2-client /etc/openvpn/client/$1.pem

# 1 argument = Client_identifier
cat <(echo -e 'client') \
<(echo -e 'proto udp') \
<(echo -e 'dev tun') \
<(echo -e 'remote 192.168.42.5 1194') \
<(echo -e 'nobind') \
<(echo -e key $1.key) \
<(echo -e 'persist-key') \
<(echo -e 'persist-tun') \
<(echo -e 'remote-cert-tls server') \
<(echo -e 'cipher AES-256-GCM') \
<(echo -e '#user nobody') \
<(echo -e '#group nobody') \
<(echo -e 'verb 3') \
    <(echo -e '<ca>') \
    ca.crt \
    <(echo -e '</ca>\n<cert>') \
    ${1}.crt \
    <(echo -e '</cert>\n<tls-crypt-v2>') \
    ${1}.pem \
    <(echo -e '</tls-crypt-v2>') \
    > ${1}.ovpn
